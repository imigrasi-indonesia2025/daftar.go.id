"use client"

import { useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { usePaymentTimer } from "@/hooks/use-payment-timer"

interface PaymentPopupProps {
  isOpen: boolean
  onClose: () => void
}

export default function PaymentPopup({ isOpen, onClose }: PaymentPopupProps) {
  const { timeLeft, isTimerActive, startTimer, formatTime } = usePaymentTimer()

  useEffect(() => {
    if (isOpen && !isTimerActive) {
      startTimer()
    }
  }, [isOpen, isTimerActive, startTimer])

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-xl font-bold">Detail Pembayaran</DialogTitle>
            <div className="flex items-center gap-2">
              <img 
                src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSUJSAOQz4oOxXz4C1YvfBb6ugF9xr2AXr3eA&s" 
                alt="Logo" 
                className="w-12 h-12 object-contain"
              />
            </div>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Payment Timer */}
          <Card className={`border-red-200 ${timeLeft > 0 ? 'bg-red-50' : 'bg-gray-100'}`}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-red-800">Batas Waktu Pembayaran</p>
                  <p className="text-xs text-red-600">
                    {timeLeft > 0 ? 'Selesaikan pembayaran sebelum waktu habis' : 'Waktu pembayaran telah habis'}
                  </p>
                </div>
                <div className="text-right">
                  <p className={`text-2xl font-bold ${timeLeft > 0 ? 'text-red-800' : 'text-gray-600'}`}>
                    {formatTime}
                  </p>
                  <p className="text-xs text-red-600">HH:MM:SS</p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Status */}
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Status:</span>
            <Badge 
              variant="secondary" 
              className={`${timeLeft > 0 ? 'bg-yellow-100 text-yellow-800' : 'bg-red-100 text-red-800'}`}
            >
              {timeLeft > 0 ? 'MENUNGGU' : 'KADALUARSA'}
            </Badge>
          </div>

          <Separator />

          {/* Payment Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-600">Kode Pembayaran</p>
              <p className="text-lg font-bold">135036000033044268</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Jumlah Pembayaran</p>
              <p className="text-lg font-bold text-green-600">Rp 653.500</p>
            </div>
          </div>

          <Separator />

          {/* Applicant Information */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Data Pemohon</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <p className="text-sm font-medium text-gray-600">Nama Lengkap</p>
                  <p className="font-medium">MUHAMMAD SUPRIYONO</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">NIK</p>
                  <p className="font-medium">3315170107890017</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Tempat, Tanggal Lahir</p>
                  <p className="font-medium">01 - 07 - 1989</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Agama</p>
                  <p className="font-medium">ISLAM</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Pekerjaan</p>
                  <p className="font-medium">KARYAWAN SWASTA</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-600">Jenis Kelamin</p>
                  <p className="font-medium">LAKI-LAKI</p>
                </div>
              </div>
              
              <div>
                <p className="text-sm font-medium text-gray-600">Alamat</p>
                <p className="font-medium">KAMPUNG RANOUSARI Col Darah 0, GROBOGAN, JAWA TENGAH</p>
              </div>
            </CardContent>
          </Card>

          <Separator />

          {/* Application Details */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-600">Tanggal Pendaftaran</p>
              <p className="font-medium">20 September 2025</p>
              <p className="text-sm text-gray-500">13:10 WIB</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-600">Tanggal Kedatangan</p>
              <p className="font-medium">22 September 2025</p>
              <p className="text-sm text-gray-500">11:30 WIB</p>
            </div>
          </div>

          <Separator />

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button 
              className="flex-1 bg-green-600 hover:bg-green-700"
              disabled={timeLeft === 0}
            >
              Unduh Disini
            </Button>
            <Button variant="outline" className="flex-1" onClick={onClose}>
              Tutup
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}