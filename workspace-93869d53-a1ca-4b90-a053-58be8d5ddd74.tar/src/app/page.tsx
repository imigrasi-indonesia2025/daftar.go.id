"use client"

import { useState } from "react"
import PaymentPopup from "@/components/payment-popup"
import { Button } from "@/components/ui/button"

export default function Home() {
  const [isPaymentPopupOpen, setIsPaymentPopupOpen] = useState(false)

  return (
    <div className="flex flex-col items-center justify-center min-h-screen gap-8 p-4 bg-gradient-to-br from-blue-50 to-indigo-100">
      <div className="flex flex-col items-center gap-4">
        <div className="relative w-32 h-32 md:w-40 md:h-40">
          <img
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcShdzgLTxIXGsA1xIfu7DXeEM_7EbPUjOrlvQ&s"
            alt="Kantor Imigrasi Logo"
            className="w-full h-full object-contain"
          />
        </div>
        <h1 className="text-3xl md:text-4xl font-bold text-gray-900 text-center">
          KANTOR IMIGRASI<br/>KELAS 1 TPI SEMARANG
        </h1>
      </div>
      
      <div className="text-center max-w-2xl">
        <p className="text-lg text-gray-600 mb-8">
          Sistem Layanan Pembayaran Online
        </p>
        
        <Button 
          onClick={() => setIsPaymentPopupOpen(true)}
          className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 text-lg"
        >
          Lihat Detail Pembayaran
        </Button>
      </div>

      <PaymentPopup 
        isOpen={isPaymentPopupOpen}
        onClose={() => setIsPaymentPopupOpen(false)}
      />
    </div>
  )
}