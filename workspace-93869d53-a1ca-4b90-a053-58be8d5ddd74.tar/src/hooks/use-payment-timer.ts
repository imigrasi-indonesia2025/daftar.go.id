"use client"

import { useState, useEffect } from "react"

const PAYMENT_TIMER_KEY = 'payment-timer-start'
const TIMER_DURATION = 2 * 60 * 60 // 2 hours in seconds

export function usePaymentTimer() {
  const [timeLeft, setTimeLeft] = useState(TIMER_DURATION)
  const [isTimerActive, setIsTimerActive] = useState(false)

  useEffect(() => {
    // Check if timer was already started
    const savedStartTime = localStorage.getItem(PAYMENT_TIMER_KEY)
    
    if (savedStartTime) {
      const startTime = parseInt(savedStartTime)
      const currentTime = Math.floor(Date.now() / 1000)
      const elapsed = currentTime - startTime
      const remaining = Math.max(0, TIMER_DURATION - elapsed)
      
      setTimeLeft(remaining)
      setIsTimerActive(remaining > 0)
    }
  }, [])

  useEffect(() => {
    if (!isTimerActive || timeLeft <= 0) return

    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          setIsTimerActive(false)
          localStorage.removeItem(PAYMENT_TIMER_KEY)
          return 0
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(timer)
  }, [isTimerActive, timeLeft])

  const startTimer = () => {
    const startTime = Math.floor(Date.now() / 1000)
    localStorage.setItem(PAYMENT_TIMER_KEY, startTime.toString())
    setTimeLeft(TIMER_DURATION)
    setIsTimerActive(true)
  }

  const resetTimer = () => {
    localStorage.removeItem(PAYMENT_TIMER_KEY)
    setTimeLeft(TIMER_DURATION)
    setIsTimerActive(false)
  }

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    const secs = seconds % 60
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`
  }

  return {
    timeLeft,
    isTimerActive,
    startTimer,
    resetTimer,
    formatTime: formatTime(timeLeft)
  }
}